package enums;

public enum Status {

    ACTIVE, OUT_OF_ORDER;


}
