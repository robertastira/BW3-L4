package enums;

public enum PassDuration {
    WEEKLY, MONTHLY
}
