package enums;

public enum Validation {
    VALIDATED,
    NOT_VALIDATED

}
