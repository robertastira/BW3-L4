package enums;

public enum ServiceType {
    ON_DUTY, IN_MAINTENANCE
}
